# Papier-JEE-project
Computer Programming AaS capstone JEE project

This project was a team project to design and implement an E-Commerce web site.
The site was to be for a fictional office supply company, and needed to include the following functionality:

Customer login
Customer order review
Customer data retrieve=al 
Customer data updating
Customer shopping and checkout
Guest shopping
Order fulfiller login
fulfiller order retrieval
fulfiller order fulfillment

This project was completed with a team of 1 front-end developer and 2 back-end developers over a single semester.
